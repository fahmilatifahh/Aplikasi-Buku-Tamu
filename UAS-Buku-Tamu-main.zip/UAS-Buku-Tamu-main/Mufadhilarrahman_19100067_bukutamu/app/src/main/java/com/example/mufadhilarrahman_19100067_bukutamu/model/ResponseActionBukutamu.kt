package com.example.mufadhilarrahman_19100067_bukutamu.model

import com.google.gson.annotations.SerializedName

class ResponseActionBukutamu(


    @field:SerializedName("pesan")
    val pesan: Any? = null,

    @field:SerializedName("data")
    val data: List<Boolean?>? = null,

    @field:SerializedName("status")
    val status: String? = null,
    )
