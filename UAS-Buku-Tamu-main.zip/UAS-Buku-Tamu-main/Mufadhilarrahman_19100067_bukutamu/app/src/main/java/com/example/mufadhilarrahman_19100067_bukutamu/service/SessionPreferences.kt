package com.example.mufadhilarrahman_19100067_bukutamu.service

import com.example.mufadhilarrahman_19100067_bukutamu.RegisterActivity

class SessionPreferences(loginActivity: RegisterActivity) {
    fun actionLogin(toString: String) {
        TODO("Not yet implemented")
    }

    fun getUserName(): Any {
        TODO("Not yet implemented")
    }
}